
 document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
    alert("Right-click is disabled on this page.");
	});
const apiKey = 'd40209307be17f5ca065db83f9e19289'; // Replace with your OpenWeatherMap API key

function populateCities() {
    const state = document.getElementById('state').value;
    const citySelect = document.getElementById('city');
    citySelect.innerHTML = '<option value="">Select City</option>'; // Reset city options

    const cities = {
        'Andhra Pradesh': ['Vijayawada', 'Visakhapatnam', 'Guntur', 'Nellore', 'Kurnool', 'Rajahmundry', 'Kadapa', 'Tirupati', 'Anantapur', 'Kakinada'],
        'Arunachal Pradesh': ['Itanagar', 'Pasighat', 'Naharlagun', 'Tawang', 'Ziro', 'Bomdila', 'Roing', 'Aalo', 'Tezu', 'Khonsa'],
        'Assam': ['Guwahati', 'Silchar', 'Dibrugarh', 'Jorhat', 'Nagaon', 'Tinsukia', 'Tezpur', 'Sivasagar', 'Karimganj', 'Bongaigaon'],
        'Bihar': ['Patna', 'Gaya', 'Bhagalpur', 'Muzaffarpur', 'Purnia', 'Darbhanga', 'Bihar Sharif', 'Ara', 'Begusarai', 'Katihar'],
        'Chhattisgarh': ['Raipur', 'Bhilai', 'Korba', 'Bilaspur', 'Durg', 'Rajnandgaon', 'Jagdalpur', 'Raigarh', 'Ambikapur', 'Dhamtari'],
        'Goa': ['Panaji', 'Margao', 'Vasco da Gama', 'Mapusa', 'Ponda', 'Bicholim', 'Curchorem', 'Sanguem', 'Valpoi', 'Canacona'],
        'Gujarat': ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 'Bhavnagar', 'Jamnagar', 'Junagadh', 'Gandhinagar', 'Gandhidham', 'Anand'],
        'Haryana': ['Gurugram', 'Faridabad', 'Panipat', 'Ambala', 'Hisar', 'Rohtak', 'Karnal', 'Yamunanagar', 'Sonipat', 'Panchkula'],
        'Himachal Pradesh': ['Shimla', 'Dharamshala', 'Mandi', 'Solan', 'Una', 'Kullu', 'Chamba', 'Bilaspur', 'Hamirpur', 'Kangra'],
        'Jharkhand': ['Ranchi', 'Jamshedpur', 'Dhanbad', 'Bokaro', 'Deoghar', 'Hazaribagh', 'Giridih', 'Ramgarh', 'Medininagar', 'Chaibasa'],
        'Karnataka': ['Bangalore', 'Mysore', 'Mangalore', 'Hubli', 'Belgaum', 'Tumkur', 'Davangere', 'Bellary', 'Bijapur', 'Shimoga'],
        'Kerala': ['Thiruvananthapuram', 'Kochi', 'Kozhikode', 'Kollam', 'Thrissur', 'Palakkad', 'Alappuzha', 'Malappuram', 'Ponnani', 'Kannur'],
        'Madhya Pradesh': ['Indore', 'Bhopal', 'Gwalior', 'Jabalpur', 'Ujjain', 'Sagar', 'Ratlam', 'Satna', 'Dewas', 'Murwara'],
        'Maharashtra': ['Mumbai', 'Pune', 'Nagpur', 'Nashik', 'Aurangabad', 'Thane', 'Solapur', 'Amravati', 'Kolhapur', 'Latur'],
        'Manipur': ['Imphal', 'Thoubal', 'Churachandpur', 'Bishnupur', 'Kakching', 'Ukhrul', 'Senapati', 'Tamenglong', 'Jiribam', 'Moirang'],
        'Meghalaya': ['Shillong', 'Tura', 'Nongstoin', 'Jowai', 'Baghmara', 'Cherrapunji', 'Williamnagar', 'Mairang', 'Mawkyrwat', 'Nongpoh'],
        'Mizoram': ['Aizawl', 'Lunglei', 'Champhai', 'Kolasib', 'Serchhip', 'Mamit', 'Saitual', 'Siaha', 'Hnahthial', 'Lawngtlai'],
        'Nagaland': ['Kohima', 'Dimapur', 'Mokokchung', 'Tuensang', 'Mon', 'Wokha', 'Zunheboto', 'Phek', 'Kiphire', 'Longleng'],
        'Odisha': ['Bhubaneswar', 'Cuttack', 'Rourkela', 'Brahmapur', 'Sambalpur', 'Puri', 'Balasore', 'Baripada', 'Jeypore', 'Bhadrak'],
        'Punjab': ['Ludhiana', 'Amritsar', 'Jalandhar', 'Patiala', 'Bathinda', 'Mohali', 'Hoshiarpur', 'Pathankot', 'Moga', 'Abohar'],
        'Rajasthan': ['Jaipur', 'Jodhpur', 'Udaipur', 'Kota', 'Bikaner', 'Ajmer', 'Alwar', 'Bharatpur', 'Pali', 'Sikar'],
        'Sikkim': ['Gangtok', 'Namchi', 'Gyalshing', 'Mangan', 'Jorethang', 'Rangpo', 'Ravangla', 'Yuksom', 'Pelling', 'Singtam'],
        'Tamil Nadu': ['Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli', 'Salem', 'Tirunelveli', 'Erode', 'Vellore', 'Thoothukudi', 'Dindigul'],
        'Telangana': ['Hyderabad', 'Warangal', 'Nizamabad', 'Khammam', 'Karimnagar', 'Ramagundam', 'Mahbubnagar', 'Siddipet', 'Adilabad', 'Suryapet'],
        'Tripura': ['Agartala', 'Dharmanagar', 'Kailasahar', 'Udaipur', 'Belonia', 'Khowai', 'Ambassa', 'Melaghar', 'Bishalgarh', 'Sonamura'],
        'Uttar Pradesh': ['Lucknow', 'Kanpur', 'Agra', 'Varanasi', 'Prayagraj', 'Meerut', 'Bareilly', 'Gorakhpur', 'Aligarh', 'Moradabad'],
        'Uttarakhand': ['Dehradun', 'Haridwar', 'Roorkee', 'Haldwani', 'Rishikesh', 'Kashipur', 'Rudrapur', 'Nainital', 'Pithoragarh', 'Mussoorie'],
        'West Bengal': ['Kolkata', 'Howrah', 'Durgapur', 'Asansol', 'Siliguri', 'Kharagpur', 'Bardhaman', 'Malda', 'Haldia', 'Berhampore']
    };

    if (state && cities[state]) {
        cities[state].forEach(city => {
            const option = document.createElement('option');
            option.value = city;
            option.textContent = city;
            citySelect.appendChild(option);
        });
    }
}

function getWeather() {
    const city = document.getElementById('city').value;
    
    if (city === '') {
        alert('Please select a city/state');
        return;
    }

    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            if (data.cod === "404") {
                alert('City not found');
                return;
            }

            const weatherDiv = document.getElementById('weather');
            const temp = data.main.temp;
            const weather = data.weather[0].description;
            const windSpeed = data.wind.speed;
            const humidity = data.main.humidity;
            const sunrise = new Date(data.sys.sunrise * 1000).toLocaleTimeString();
            const sunset = new Date(data.sys.sunset * 1000).toLocaleTimeString();
            const precipitation = data.rain ? `${data.rain['1h']} mm` : 'No precipitation';

            weatherDiv.innerHTML = `
                <h2>Weather in ${city}</h2>
                <p><b>Temperature:</b> ${temp}°C</p>
                <p><b>Condition:</b> ${weather}</p>
                <p><b>Wind Speed:</b> ${windSpeed} m/s</p>
                <p><b>Humidity:</b> ${humidity}%</p>
                <p><b>Precipitation:</b> ${precipitation}</p>
                <p><b>Sunrise:</b> ${sunrise}</p>
                <p><b>Sunset:</b> ${sunset}</p>
            `;

            const lat = data.coord.lat;
            const lon = data.coord.lon;
            const uvApiUrl = `https://api.openweathermap.org/data/2.5/onecall?lat=${lat}&lon=${lon}&exclude=minutely,hourly,daily,alerts&appid=${apiKey}`;

            return fetch(uvApiUrl);
        })
        .then(response => response.json())
        .then(uvData => {
            const uvIndex = uvData.current.uvi;
            const uvDiv = document.createElement('p');
            uvDiv.textContent = `UV Index: ${uvIndex}`;
            document.getElementById('weather').appendChild(uvDiv);
        })
        .catch(error => console.error('Error fetching data:', error));
}
